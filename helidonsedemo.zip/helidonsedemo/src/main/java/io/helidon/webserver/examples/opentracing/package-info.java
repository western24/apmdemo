/**
 * An example of WebServer app supporting Open Tracing.
 */
package io.helidon.webserver.examples.opentracing;