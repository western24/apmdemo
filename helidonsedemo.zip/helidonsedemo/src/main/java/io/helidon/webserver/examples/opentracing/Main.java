package io.helidon.webserver.examples.opentracing;

import io.helidon.common.LogConfig;
import io.helidon.config.Config;
import io.helidon.config.ConfigSources;
import io.helidon.media.jsonp.JsonpSupport;
import io.helidon.tracing.TracerBuilder;
import io.helidon.webserver.Routing;
import io.helidon.webserver.WebServer;
import io.helidon.tracing.Tracer;
import io.helidon.tracing.Span;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;

public final class Main {

    private static WebServer webServer = null;

    private Main() {}

    public static void main(String[] args) {

        // load logging configuration
        LogConfig.configureRuntime();

        // By default this will pick up application.yaml from the classpath
        Config config = Config.create();

        // webserver configuration
        webServer = WebServer.builder(
                Routing.builder()
                        .any((req, res) -> {
                            System.out.println("Received another request.");
                            req.next();
                        })
                        .get("/helidon/api/weather", (req, res) -> {
                            //API Call to JMA "This is traced as Span name is GET automatically"
                            try {
                                HttpGet request = new HttpGet("https://www.jma.go.jp/bosai/forecast/data/overview_forecast/130000.json");
                                CloseableHttpClient httpClient = HttpClients.createDefault();
                                CloseableHttpResponse response = httpClient.execute(request);
                                res.headers().add("Content-Type", "application/json");
                                res.send(EntityUtils.toString(response.getEntity()));
                            } catch (Exception e) {
                            }
                            
                            // Start trace span
                            mainWork();
                        }))
                .config(config.get("server"))
                .tracer(TracerBuilder.create(config.get("tracing")).build())
                .addMediaSupport(JsonpSupport.create())
                .build();

        webServer.start()
                .whenComplete((server, throwable) -> {
                    System.out.println("Started at http://localhost:" + webServer.port() + "/helidon/api/weather");
                });
    }

    private static void doWork(int index, Span parentspan) {
        try {
            // Create span
            Tracer tracer = webServer.configuration().tracer();
            Span span = tracer.spanBuilder("doWork:" + index).parent(parentspan.context()).start();

            // simulate some random work.
            for (int i = 0; i <= (int)Math.floor(Math.random() * 40000000); i++) {
                // empty
            }

            // Make sure to end this child span! If you don't, it will continue to track work beyond 'doWork'!
            span.end();

        } catch(Exception e) {
        }
    }

    private static void mainWork() {
        try {
            // Create parent span
            Tracer tracer = webServer.configuration().tracer();
            Span span = tracer.spanBuilder("main").start();

            // Create child span
            for(int i = 0; i < 3; i++) {
                doWork(i, span);
            }

            // Be sure to end the parent span!
            span.end();

        } catch(Exception e) {
        }
    }
}