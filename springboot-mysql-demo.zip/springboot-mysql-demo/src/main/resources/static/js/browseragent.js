document.write('<script>\n');
document.write('window.apmrum = (window.apmrum || {});\n');
document.write("window.apmrum.serviceName='<APM Browser>';\n")
document.write("window.apmrum.webApplication='<Web App Name>';\n");
document.write("window.apmrum.ociDataUploadEndpoint='<データ・アップロード・エンドポイント>';\n");
document.write("window.apmrum.OracleAPMPublicDataKey='<auto_generated_public_datakey>';\n");
document.write('</script>\n');
document.write('<script async crossorigin="anonymous" src="<データ・アップロード・エンドポイント>/static/jslib/apmrum.min.js"></script>');