package com.oracle.springboot.facade;

import com.oracle.springboot.entity.Product;

import java.util.List;

public interface MainFacade {

    List<Product> selectProductList();

    Product selectProductByProductname(String productname);

    int insertProduct(Product product);

    int updateProductByProductname(Product product);

    int deleteProductByProductname(String productname);

    void dummyMethod1();
    void dummyMethod2();
}
