package com.oracle.springboot.facade.impl;

import com.oracle.springboot.entity.Product;
import com.oracle.springboot.facade.MainFacade;
import com.oracle.springboot.service.MainService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.aop.framework.AopContext;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

@Component
@Transactional
@Slf4j
public class MainFacadeImpl implements MainFacade {

    @Resource
    MainService mainService;

    @Override
    public List<Product> selectProductList() {
        MainFacade mainFacade = (MainFacade)AopContext.currentProxy();
        mainFacade.dummyMethod1();
        return mainService.selectProductList();
    }

    @Override
    public Product selectProductByProductname(String productname) {
        return mainService.selectProductByProductname(productname);
    }

    @Override
    public int insertProduct(Product product) {
        return mainService.insertProduct(product);
    }

    @Override
    public int updateProductByProductname(Product product) {
        return mainService.updateProductByProductname(product);
    }

    @Override
    public int deleteProductByProductname(String productname) {
        return mainService.deleteProductByProductname(productname);
    }

    @Override
    public void dummyMethod1() {
        try {
            Thread.sleep(1);
            MainFacade mainFacade = (MainFacade)AopContext.currentProxy();
            mainFacade.dummyMethod2();
            log.info("### in MainFacadeImpl.dummyMethod1() ###");
        } catch (InterruptedException e) {
            // do nothing
        }
    }

    @Override
    public void dummyMethod2() {
        try {
            Thread.sleep(2);
            log.info("### in MainFacadeImpl.dummyMethod2() ###");
        } catch (InterruptedException e) {
            // do nothing
        }
    }
}
