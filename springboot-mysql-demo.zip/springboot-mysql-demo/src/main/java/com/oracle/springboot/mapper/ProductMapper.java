package com.oracle.springboot.mapper;

import com.oracle.springboot.entity.Product;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ProductMapper {

    List<Product> selectProductList();

    Product selectProductByProductname(@Param("productname") String productname);

    int insertProduct(Product product);

    int updateProductByProductname(Product productname);

    int deleteProductByProductname(@Param("productname") String productname);
}
