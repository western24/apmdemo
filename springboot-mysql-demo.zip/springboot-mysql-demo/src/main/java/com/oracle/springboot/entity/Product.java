package com.oracle.springboot.entity;

public class Product {

    private String productname;
    private String unitprice;
    private String unit;

    public Product() {
    }

    public Product(String productname, String unitprice, String unit) {
        this.productname = productname;
        this.unitprice = unitprice;
        this.unit = unit;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public String getUnitprice() {
        return unitprice;
    }

    public void setUnitprice(String unitprice) {
        this.unitprice = unitprice;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }
}
