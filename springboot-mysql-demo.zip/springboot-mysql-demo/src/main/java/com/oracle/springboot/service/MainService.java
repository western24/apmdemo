package com.oracle.springboot.service;

import com.oracle.springboot.entity.Product;

import java.util.List;

public interface MainService {

    List<Product> selectProductList();

    Product selectProductByProductname(String productname);

    int insertProduct(Product product);

    int updateProductByProductname(Product productname);

    int deleteProductByProductname(String productname);

}
