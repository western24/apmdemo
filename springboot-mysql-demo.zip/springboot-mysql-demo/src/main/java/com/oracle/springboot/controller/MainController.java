package com.oracle.springboot.controller;

import com.oracle.springboot.entity.Product;
import com.oracle.springboot.facade.MainFacade;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import java.util.List;

@Controller
@RequestMapping("/main")
@Slf4j
public class MainController {

    @Resource
    MainFacade mainFacade;

    @GetMapping(value = "/products/goList")
    public String selectProductList(Model model) {
        List<Product> products = mainFacade.selectProductList();
        model.addAttribute("products", products);
        return "products/list";
    }

    private String method3(){
        log.info("###in MainController-method3()###");
        return "method3";
    }

    @GetMapping(value = "/products/goInsert")
    public String goInsertProduct(Model model, Product product) {
        log.info("###in MainController-goInsertProduct()###");
        return "products/insert";
    }

    @GetMapping(value = "/products/goUpdate/{productname}")
    public String goUpdateByProductname(Model model, @PathVariable("productname") String productname) {
        Product product = mainFacade.selectProductByProductname(productname);
        model.addAttribute("product", product);
        return "products/update";
    }

    @PostMapping(value = "/products/doInsert")
    public String insertProduct(Model model, Product product) {
        log.info("###in MainController-insertProduct()###");
        int result = mainFacade.insertProduct(product);
        log.info("insert result is:" + result);
        return "redirect:/main/products/goList";
    }

    @PostMapping(value = "/products/doUpdate/{productname}")
    public String updateProductByProductname(Model model, @PathVariable("productname") String productname, Product product) {
        product.setProductname(productname);
        int result = mainFacade.updateProductByProductname(product);
        log.info("update result is:" + result);
        return "redirect:/main/products/goList";
    }

    @GetMapping(value = "/products/doDelete/{productname}")
    public String deleteProductByProduct(Model model, @PathVariable("productname") String productname) {
        log.info("###in MainController-insertProduct()###");
        int result = mainFacade.deleteProductByProductname(productname);
        log.info("delete result is:" + result);
        List<Product> products = mainFacade.selectProductList();
        return "redirect:/main/products/goList";
    }

}
