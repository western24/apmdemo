package com.oracle.springboot.service.impl;

import com.oracle.springboot.entity.Product;
import com.oracle.springboot.mapper.ProductMapper;
import com.oracle.springboot.service.MainService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class MainServiceImpl implements MainService {

    @Resource
    ProductMapper productMapper;

    @Override
    public List<Product> selectProductList() {
        return productMapper.selectProductList();
    }

    @Override
    public Product selectProductByProductname(String productname) {
        return productMapper.selectProductByProductname(productname);
    }

    @Override
    public int insertProduct(Product product) {
        return productMapper.insertProduct(product);
    }

    @Override
    public int updateProductByProductname(Product productname) {
        return productMapper.updateProductByProductname(productname);
    }

    @Override
    public int deleteProductByProductname(String productname) {
        return productMapper.deleteProductByProductname(productname);
    }
}
