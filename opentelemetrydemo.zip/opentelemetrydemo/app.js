/*app.js*/
const express = require("express");

/*Opentelemetry*/
const tracing = require('./tracing');

const PORT = parseInt(process.env.PORT || "8383");
const app = express();

function error(status, msg) {
  var err = new Error(msg);
  err.status = status;
  return err;
}

app.get('/opentelemetry/api/weather', function (req, res) {
  
  //API Call to JMA "This is traced as Span name is GET automatically"
  var request = require('request');
  var options = {
    url: 'https://www.jma.go.jp/bosai/forecast/data/overview_forecast/130000.json',
    method: 'GET',
    json: true
  }
  request(options, function (error, response, body) {
  if (!error && response.statusCode === 200) {
      res.json(body);
  }
  });
  
  //How to create span
  //Please check here. https://opentelemetry.io/docs/instrumentation/js/manual/
  const opentelemetry = require("@opentelemetry/api");
  const tracer = opentelemetry.trace.getTracer('Test Span Scope');
  
  const mainWork = () => {
    tracer.startActiveSpan('main', (parentSpan) => {
      for (let i = 0; i < 3; i += 1) {
        doWork(i);
      }
      // Be sure to end the parent span!
      parentSpan.end();
    });
  };
  
  const doWork = (i) => {
    tracer.startActiveSpan(`doWork:${i}`, (span) => {
      // simulate some random work.
      for (let i = 0; i <= Math.floor(Math.random() * 40000000); i += 1) {
        // empty
      }
        // Make sure to end this child span! If you don't,
      // it will continue to track work beyond 'doWork'!
      span.end();
    });
  };

  mainWork();
});

app.use(function(err, req, res, next){
  res.status(err.status || 500);
  res.send({ error: err.message });
});

app.use(function(req, res){
  res.status(404);
  res.send({ error: "Sorry, can't find that" })
});

app.listen(PORT, () => {
  console.log(`Listening for requests on http://localhost:${PORT}/opentelemetry/api/weather`);
});